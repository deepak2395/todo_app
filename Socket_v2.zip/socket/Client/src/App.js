import React, { Component } from 'react';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom'
import todo from './components/Todo';
import login from './components/login';
import Page404 from './components/pagenotfound';

/* function requireLogin() {
  const { user_id, session_key } = store.getState().logReducer;
  store.dispatch(login_check({ user_id: user_id, session_key: session_key }))
  const { logged_in } = store.getState().logReducer;
  if (!logged_in) {
    browserHistory.push('#/login');
    hashHistory.push('/login');
  }
} */

class App extends Component {
  render() {
    return (
      /*  <BrowserRouter>
         <Route path='/'>
           <Redirect to="/login" />
         </Route>
         <Route path='/login' component={login} />
         <Route path='/todo' component={todo} />
       </BrowserRouter> */
      <BrowserRouter>
        <Switch>
          <Route exact path="/" exact component={todo} />
          <Route exact path="/login" exact component={login} />
          <Route exact path="/todo" component={todo} /* onEnter={requireLogin} */ />
          <Route path="*" component={Page404} />
        </Switch>
      </BrowserRouter>
    );
  }
}

export default App;
