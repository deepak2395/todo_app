import React, { useState, useEffect } from 'react';
import socketIOClient from "socket.io-client";
import { Redirect } from 'react-router-dom'
//import { browserHistory } from 'history'
import { useRedirect } from 'react-router'
import axios from "axios";
//import './Todo.css';

const endpoint = "http://127.0.0.1:4001"
const socket = socketIOClient(endpoint);


function Login() {

    var [user, setUser] = useState('');
    var [password, setPass] = useState('');
    var [login, setLogin] = useState(false);

    const skiplogin = (e) => {
        setUser(e.target.value)
    }

    const skiplogin1 = (e) => {
        setPass(e.target.value)
    }

    useEffect(() => {
        /*  if (true) {
             // browserHistory.push('/todo')
 
         } */
    }, []);

    const putDataToDB = async (username, password) => {
        await axios.post('http://localhost:4001/saveLoginData', {
            username: username,
            password: password,
        }).then(function (data) {
            if (data.success == true) {
                setLogin(true)
            }
        })
        // return (<Redirect to="/todo" />);
        /*   const redirect = useRedirect();
          redirect('/about') */

    };

    return (

        <div className="todo-container">
            <div className="tasks">
                <form>
                    <div className="tags">Username:</div>
                    <input className="username" type="text" placeholder="user name" onChange={skiplogin} value={user}></input>
                    <div className="tags">password:</div>
                    <input className="username" type="password" placeholder="user name" onChange={skiplogin1} value={password}></input>
                    <button onClick={() => putDataToDB(user, password)}>Login</button>
                </form>
            </div>


            <div className="instruction">Enter User name to continue....</div>


        </div >
    );
}

export default Login;