const mongoose = require('mongoose');
const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const axios = require("axios");
const cors = require('cors');
const bodyParser = require('body-parser')

const port = process.env.PORT || 4001;

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
const router = express.Router();
const index = require("./routes/index");
app.use('/', router);
app.use('/api', index);


const Login = require('./models/login');
const Todo = require('./models/todoData');

const server = http.createServer(app);

const io = socketIo(server); // < Interesting!

var value = ""

io.on("connection", socket => {
    console.log("New client connected")
    getApiAndEmit(socket)
    socket.on("disconnect", () => console.log("Client disconnected"));
});


const getApiAndEmit = async socket => {
    try {
        socket.username = "Anonymous"
        //listen on new_message
        socket.on('task', async (data) => {
            //value = data
            //broadcast the new message
            io.sockets.emit('FromAPI', { message: data, username: socket.username });
            var result = await UpdateTodoData(data)
            console.log(result)
        })

        socket.on('gettask', (data) => {
            //broadcast the new message
            var val = GetTodoData()
            io.sockets.emit('GetFromAPI', { message: val.data, username: socket.username });

        })


    } catch (error) {
        console.error(`Error: ${error.code}`);
    }
};

// this is our MongoDB database
const dbRoute = 'mongodb+srv://AchuPro:evTDVCDnPxNoN4Z8@back-api-1uqs2.mongodb.net/Diwali?retryWrites=true&w=majority'

mongoose.connect(dbRoute, { useUnifiedTopology: true, useNewUrlParser: true, useCreateIndex: true });

let db = mongoose.connection;

db.once('open', () => {
    console.log('connected to the database')
});

// checks if connection with the database is successful
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

router.get('/getTodoData', async (req, res) => {
    var TodoList = await GetTodoData()
    return res.json(TodoList.data)
});

function GetTodoData() {
    return new Promise((resolve, reject) => {
        Todo.findOne((err, data) => {
            if (err) resolve({ success: false, error: err });
            /*  resolve({ success: true, data: data[data.length - 1].todolist }); */
            resolve({ success: true, data: data.todolist });
        });
    })
}

router.post('/updateTodoData', async (req, res) => {
    var TodoList = await UpdateTodoData(req.body)
    return res.json(TodoList)
});

function UpdateTodoData(value) {
    return new Promise(async (resolve, reject) => {
        /* let datas = new Todo();
        datas.todolist = value
        datas.save((err) => {
            if (err) resolve({ success: false, error: err });
            resolve({ success: true });
        }); */

        const filter = { "todolist.user": "admin" };
        const update = { "todolist": value }

        await Todo.updateMany(filter, update, function (err, data) {
            resolve({ success: true })
        })

    })
}

function SaveLogin(req) {
    return new Promise(async (resolve, reject) => {
        let data = new Login()

        const { username, password } = req.body;
        data.user = username;
        data.password = password;
        await data.save(data, function (err, data) {
            if (err) resolve({ success: false, error: err });
            resolve({ success: true });
        });
    })
}

router.post('/saveLoginData', async (req, res) => {

    var LoginData = await SaveLogin(req)
    return res.json(LoginData)

});


server.listen(port, () => console.log(`Listening on port ${port}`))
