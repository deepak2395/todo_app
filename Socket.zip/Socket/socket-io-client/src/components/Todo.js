import React, { useState, useEffect } from 'react';
import socketIOClient from "socket.io-client";
import './Todo.css';

const endpoint = "http://127.0.0.1:4001"
const socket = socketIOClient(endpoint);


function Task({ task, index, completeTask, removeTask, editTask }) {
    return (
        <div>
            <div
                className="task" title={"inserted by " + task.user} onChange={(e) => editTask(index, e.target.value)}
                style={{ textDecoration: task.completed ? "line-through" : "" }}
            >
                {task.title}
                <div className="time">{task.time}</div>
                <button style={{ background: "red" }} onClick={() => removeTask(index)}>x</button>
                <button onClick={() => completeTask(index)}>Complete</button>
            </div>

        </div>
    );
}

function CreateTask({ user, task, addTask, time }) {

    const [value, setValue] = useState("");

    const handleSubmit = e => {
        const date = new Date()
        var dateval = date.toLocaleString()
        e.preventDefault();
        if (!value) return;
        addTask(value);
        /* setTimeFun(dateval) */
        setValue("");
        var newtasks = [...task, { title: value, completed: false, user: user, time: dateval }];
        socket.emit('task', { listoftask: newtasks, user: user })
    }
    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                className="input"
                value={value}
                placeholder="Add a new task"
                onChange={e => setValue(e.target.value)}
            />
        </form>
    );
}

function Todo() {
    const [tasksRemaining, setTasksRemaining] = useState(0);
    var [user, setUser] = useState('');
    var [time, setTime] = useState('');
    var [bool, setBool] = useState(false);
    const [tasks, setTasks] = useState([
        {
            title: "Grab some Pizza",
            completed: true,
            user: 'default',
            time: "4/11/2020, 3:24:41 PM"
        },
        {
            title: "Do your workout",
            completed: true,
            user: 'default',
            time: "4/11/2020, 3:24:41 PM"
        },
        {
            title: "Hangout with friends",
            completed: false,
            user: 'default',
            time: "4/11/2020, 3:24:41 PM"
        }
    ]);

    useEffect(() => {
        const endpoint = "http://127.0.0.1:4001"
        const socket = socketIOClient(endpoint);
        //  socket.emit('gettask', { listoftask: tasks })
    });

    socket.on("FromAPI", tasks => {
        console.log(tasks)
        setTasks(tasks.message.listoftask)
    });

    socket.on("GetFromAPI", tasks => {
        //console.log(tasks)
        setTasks(tasks.message.listoftask)
    });

    useEffect(() => { setTasksRemaining(tasks.filter(task => !task.completed).length) });


    const addTask = title => {
        const newTasks = [...tasks, { title, completed: false, user: user, time: time }];
        setTasks(newTasks);
    };

    const completeTask = index => {
        const newTasks = [...tasks];
        newTasks[index].completed = true;
        socket.emit('task', { listoftask: newTasks })
        setTasks(newTasks);
    };

    const editTask = (index, value) => {
        const newTasks = [...tasks];
        newTasks[index].title = value;
        socket.emit('task', { listoftask: newTasks })
        setTasks(newTasks);
    };

    const removeTask = index => {
        const newTasks = [...tasks];
        const createdUser = newTasks[index].user
        const currentUser = document.getElementsByTagName('input')[0].value

        if (currentUser == createdUser) {
            newTasks.splice(index, 1);
            socket.emit('task', { listoftask: newTasks })
            setTasks(newTasks);
        } else {
            alert('deletion not allowed for others task')
        }
    };

    const skiplogin = (e) => {
        setUser(e.target.value)
    }

    const setTimeFun = (value) => {
        setTime(value)
    }

    const userhandleSubmit = (e) => {

        e.preventDefault();
        if (e.target.value != "") {
            setBool(true)
        }
    }

    return (

        <div className="todo-container">
            <div className="tasks">
                <form onSubmit={userhandleSubmit}>
                    <div className="tags">Username:</div>
                    {bool ?
                        <input className="username mystyle" contentEditable="false" type="text" placeholder="user name" onChange={skiplogin} value={user} disabled></input>
                        :
                        <input className="username" type="text" placeholder="user name" onChange={skiplogin} value={user}></input>
                    }
                </form>
            </div>

            {bool ?
                <div>
                    <div className="header">Pending tasks ({tasksRemaining})</div>
                    <div className="tasks">
                        {tasks.map((task, index) => (
                            <Task
                                task={task}
                                index={index}
                                completeTask={completeTask}
                                removeTask={removeTask}
                                editTask={editTask}
                                key={index}
                            />
                        ))}
                    </div>
                    <div className="create-task" >
                        <CreateTask time={time} user={user} task={tasks} addTask={addTask} />
                    </div>
                </div>

                :

                <div className="instruction">Enter User name to continue....</div>
            }

        </div >
    );
}

export default Todo;