const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const axios = require("axios");

const port = process.env.PORT || 4001;
const index = require("./routes/index");

const app = express();
app.use(index);

const server = http.createServer(app);

const io = socketIo(server); // < Interesting!

var value = ""

io.on("connection", socket => {
    console.log("New client connected")
    getApiAndEmit(socket)
    socket.on("disconnect", () => console.log("Client disconnected"));
});


const getApiAndEmit = async socket => {
    try {
        socket.username = "Anonymous"
        //listen on new_message
        socket.on('task', (data) => {
            value = data
            //broadcast the new message
            io.sockets.emit('FromAPI', { message: data, username: socket.username });
        })

        socket.on('gettask', (data) => {
            //broadcast the new message
            io.sockets.emit('GetFromAPI', { message: value, username: socket.username });
        })
    } catch (error) {
        console.error(`Error: ${error.code}`);
    }
};

server.listen(port, () => console.log(`Listening on port ${port}`))
